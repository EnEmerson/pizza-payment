package edu.txstate.e_e106.pizzapayment;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {

    double toppingFee = 1.50;
    double drinkFee = 2.25;
    double total;
    int toppings;
    double pizzaCost = 10.00;
    DecimalFormat USD = new DecimalFormat("###,##0.00");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final TextView numOfToppings = findViewById(R.id.txtToppingsInput);
        final RadioButton water = findViewById(R.id.radWater);
        final RadioButton softDrink = findViewById(R.id.radDrink);
        final Spinner crustType = findViewById(R.id.spnCrustType);
        final TextView displayCost = findViewById(R.id.lblCostDisplay);
        final Button orderButton = findViewById(R.id.btnOrder);

        orderButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                total += pizzaCost;
                toppings = Integer.parseInt(numOfToppings.getText().toString());
                String drink = "";

                if(toppings > 1){
                    total += (toppings - 1) * toppingFee;
                }
                if(water.isChecked()){
                    drink = "Water";
                }
                if(softDrink.isChecked()){
                    total += drinkFee;
                    drink = "Soft Drink";
                }

                String crust = crustType.getSelectedItem().toString();

                displayCost.setText("You ordered a " + crust + " crust pizza with a " + drink + ". The total will be: $" + USD.format(total));
            total = 0;
            }
        });
    }
}
